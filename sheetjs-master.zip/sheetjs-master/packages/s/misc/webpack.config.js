module.exports = {
  output: {
    libraryTarget: "var",
    library: "S"
  },
  node: {
    process: false,
    browser: false
  }
}